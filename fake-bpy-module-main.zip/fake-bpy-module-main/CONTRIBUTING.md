# Contribution

## Contribute to this project

We welcome any contributions to this project.  
If you want to contribute to this project, please send pull request to
[**main** branch](https://github.com/nutti/fake-bpy-module/tree/main).  
**DO NOT** send pull request to other branches.

## Support this project

Continuing enhancement and maintenance of this project is difficult
without your support.  
To realize the long support of this project, your support is helpful.  
You can support the development of this project via
**[GitHub Sponsors](https://github.com/sponsors/nutti)**.

Some plans give you the right to add your name/icon as project authors.  
If you reach the purchases $10, $30, $50 cumulatively, send me additional info
(name/icon and purchases information) to us by using Twitter or other
communication methods.

Note: Adding your name/icon is optional
