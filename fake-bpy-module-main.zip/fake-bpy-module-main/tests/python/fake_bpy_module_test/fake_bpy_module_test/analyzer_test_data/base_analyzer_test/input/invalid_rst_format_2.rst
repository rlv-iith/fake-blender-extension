.. module:: module_1


.. function:: function_1(arg_1, arg_2="test")

   :arg arg_1: function_1 arg_1 description
   :type arg_1: function_1 arg_1 type

   function_1 description long long long
long long long

   .. function:: invalid

