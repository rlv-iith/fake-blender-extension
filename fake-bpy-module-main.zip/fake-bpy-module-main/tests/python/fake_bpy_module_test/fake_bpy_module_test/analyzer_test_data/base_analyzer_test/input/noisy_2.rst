Noise(Noise)
=================

.. currentmodule:: module_1

base class --- BaseClass1, BaseClass2

.. hlist::
    .. class:: Noise

    Noise


.. class:: ClassA(BaseClass1, BaseClass2)

    ClassA description

    .. attribute:: attr_1

        attr_1
        description

        :type: attr_1 type,
         long

    .. classmethod:: classmethod_1()

        classmethod_1
        description

    .. staticmethod:: staticmethod_1(a, b)

        staticmethod_1
        description

Noise

.. class:: ClassB(BaseClass1)

    ClassB
    description

    .. data:: data_1

        data_1
        description

        :type: data_1 type

    .. method:: method_1(arg_1=5.4)

        method_1
        description

        :arg arg_1: method_1
           arg_1 description
        :type arg_1: method_1 arg_1
           type
        :return: method_1 return
           description
        :rtype: method_1
           return type

     .. seealso:: Noise

Noise

.. data:: DATA_1

    DATA_1
    description

    :type: DATA_1
      type


.. DATA:: DATA_2

    DATA_2
    description

    :type: DATA_2
      type


.. hlist:: Noise


.. function:: function_1(arg_1=[[1.3, -3.4], [4.5, -0.9]])

    function_1
    description

    :arg arg_1: function_1
        arg_1 description
    :type arg_1: function_1 arg_1
        type
    :return: function_1 return
        description
    :rtype: function_1
        return type


.. function:: function_2(arg_1, \
     arg_2="test")

    function_2
    description

    :arg arg_1: function_2 arg_1 description
    :type arg_1: function_2 arg_1 type
    :arg arg_2: function_2 arg_2 description
    :type arg_2: str


Noise
