.. module:: module_1

.. data:: DATA_1 (Deprecated)

.. data:: DATA_2 (Deprecated: This data is deprecated)

.. function:: function_1(arg_1) (Deprecated)
