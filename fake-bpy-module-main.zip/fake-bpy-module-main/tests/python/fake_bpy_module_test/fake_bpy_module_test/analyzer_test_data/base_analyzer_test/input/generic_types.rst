.. module:: module_1

.. class:: ClassA

   :generic-types: _GenericType1

   .. method:: method_1(arg_1, arg_2)

      :type arg_1: _GenericType1
      :type arg_2: _GenericType2
      :generic-types: _GenericType2

.. function:: method_1(arg_1)

   :type arg_1: _GenericType1
   :generic-types: _GenericType1
