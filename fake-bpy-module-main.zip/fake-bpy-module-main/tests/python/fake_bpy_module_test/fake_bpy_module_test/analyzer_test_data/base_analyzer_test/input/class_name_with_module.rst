.. module:: module_1

.. class:: module_1.ClassA
