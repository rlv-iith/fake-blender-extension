.. module:: module_1


.. enum:: EnumA

   EnumA description

   :ENUM_ITEM_1: ENUM_ITEM_1 description
