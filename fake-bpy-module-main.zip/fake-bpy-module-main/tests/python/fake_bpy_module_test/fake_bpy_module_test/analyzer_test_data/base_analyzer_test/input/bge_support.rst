.. module:: module_1


.. function:: function_1(arg_1, arg_2)

   function_1 description

   :arg arg_1: function_1 arg_1 description
   :type arg_1: function_1 arg_1 type
   :arg arg_2: function_1 arg_2 description
   :type arg_2: function_1 arg_2 type


.. function:: function_2(arg_1) (Deprecated)

   function_2 description

   :arg arg_1: function_2 arg_1 description
   :type arg_1: function_2 arg_1 type


.. data:: DATA_1

   DATA_1 description


.. data:: DATA_2 (Deprecated)

   DATA_2 description
