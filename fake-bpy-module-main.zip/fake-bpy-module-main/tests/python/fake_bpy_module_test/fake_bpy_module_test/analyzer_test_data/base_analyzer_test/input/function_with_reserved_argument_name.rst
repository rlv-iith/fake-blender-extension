.. module:: module_1


.. function:: function_1(async)

.. function:: function_2(async=123)
