.. module:: module_1


.. function:: function_1(arg_1, arg_2, arg_3='NONE', arg_4=True, arg_5)

.. function:: function_2(arg_1={}, *, arg_2=None, **kwargs)

.. function:: function_3(arg_1, arg_2="", *, arg_3, arg_4=123, **kwargs)
