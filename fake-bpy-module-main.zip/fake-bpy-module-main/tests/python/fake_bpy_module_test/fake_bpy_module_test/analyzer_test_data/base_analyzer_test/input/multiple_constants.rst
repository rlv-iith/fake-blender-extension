.. module:: module_1


.. data:: DATA_1

   DATA_1 description


.. attribute:: DATA_2

   :type: DATA_2 type
