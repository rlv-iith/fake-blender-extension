.. module:: module_1

.. class:: ClassA(arg_1, arg_2, arg_3=None)

.. class:: ClassB(BaseClassA, BaseClassB)
