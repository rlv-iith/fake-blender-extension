.. module:: module_1


.. function:: function_1(arg_1, arg_2)

   function_1 description

   :arg arg_1: function_1 arg_1 description
   :type arg_1: function_1 arg_1 type
   :param arg_2: function_1 arg_2 description
   :type arg_2: function_1 arg_2 type


.. method:: method_1()

   method_1 description

   :return: method_1 return description
   :rtype: method_1 return type
