.. module:: module_1


.. function:: function_1(arg_1, arg_2="test", arg_3=1234, arg_4=sys.float_info.max)

   function_1 description

   :arg arg_1: function_1 arg_1 description
   :type arg_1: function_1 arg_1 type
   :arg arg_2: function_1 arg_2 description
   :type arg_2: function_1 arg_2 type
   :arg arg_3: function_1 arg_3 description
   :type arg_3: function_1 arg_3 type
   :arg arg_4: function_1 arg_4 description
   :type arg_4: function_1 arg_4 type
   :return: function_1 return description
   :rtype: function_1 return type
