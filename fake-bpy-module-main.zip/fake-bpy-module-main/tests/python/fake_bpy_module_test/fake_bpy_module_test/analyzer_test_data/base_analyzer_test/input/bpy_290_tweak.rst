.. module:: bpy.types.ClassA


.. class:: ClassA

   ClassA description

   .. attribute:: attr_1

      attr_1 description

      :type: attr_1 type
