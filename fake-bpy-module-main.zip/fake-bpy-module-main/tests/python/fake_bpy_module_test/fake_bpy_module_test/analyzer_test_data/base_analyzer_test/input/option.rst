.. module:: module_1

.. class:: ClassA

   .. method:: method_1()

      :option function: overload

   .. method:: method_2(arg_1)

      :type arg_1: method_2 arg_1 type
      :mod-option arg arg_1: update-argument-type

   .. method:: method_3(arg_1)

      :type arg_1: method_3 arg_1 type
      :mod-option arg arg_1: skip-refine
