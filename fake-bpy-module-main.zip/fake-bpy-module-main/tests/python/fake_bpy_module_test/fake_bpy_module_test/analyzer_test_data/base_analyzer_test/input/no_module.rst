base class --- BaseClass1, BaseClass2

.. class:: ClassA

   ClassA description

   .. attribute:: attr_1

      attr_1 description

      :type: attr_1 type

   .. method:: method_1()

      method_1 description


.. class:: ClassB

   ClassB description

   .. data:: data_1

      data_1 description

      :type: data_1 type

   .. method:: method_1(arg_1=5.4)

      method_1 description

      :arg arg_1: method_1 arg_1 description
      :type arg_1: method_1 arg_1 type
      :return: method_1 return description
      :rtype: method_1 return type
