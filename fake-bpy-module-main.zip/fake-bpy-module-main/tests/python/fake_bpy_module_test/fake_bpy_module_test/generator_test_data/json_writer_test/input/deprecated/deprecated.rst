.. module:: module_1

.. data:: DATA_1 (Deprecated)

.. function:: function_1(arg_1) (Deprecated)
