.. module:: module_1


.. data:: DATA_1

   DATA_1 description

   :type: int
