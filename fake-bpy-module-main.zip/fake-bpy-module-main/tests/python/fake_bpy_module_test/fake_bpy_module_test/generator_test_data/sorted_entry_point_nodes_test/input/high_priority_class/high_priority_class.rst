.. module:: module_1

.. class:: a_class

.. class:: c_class

.. class:: bpy_prop_collection

.. class:: bpy_prop_array

.. class:: bpy_struct

.. class:: b_class