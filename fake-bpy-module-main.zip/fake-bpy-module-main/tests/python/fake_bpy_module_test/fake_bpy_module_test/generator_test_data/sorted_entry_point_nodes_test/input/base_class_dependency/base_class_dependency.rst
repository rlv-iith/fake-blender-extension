.. module:: module_1

.. class:: SubClassC

   .. base-class:: `ClassA`, `SubClassB`

.. class:: SubClassA

   .. base-class:: `ClassA`

.. class:: ClassA

.. class:: SubClassB

   .. base-class:: `ClassB`

.. class:: ClassB
