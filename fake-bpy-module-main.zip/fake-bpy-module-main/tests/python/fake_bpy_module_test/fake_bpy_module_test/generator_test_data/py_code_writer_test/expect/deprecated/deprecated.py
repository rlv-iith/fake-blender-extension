import typing
import collections.abc
import typing_extensions
import numpy.typing as npt


def function_1(arg_1):
    """(Deprecated)"""


DATA_1: typing.Any = None
""" (Deprecated)
"""
