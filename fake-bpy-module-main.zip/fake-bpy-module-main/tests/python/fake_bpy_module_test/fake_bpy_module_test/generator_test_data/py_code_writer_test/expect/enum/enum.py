import typing
import collections.abc
import typing_extensions
import numpy.typing as npt

type EnumA = typing.Literal[
    "ENUM_ITEM_1",  # ENUM_ITEM_1 description
]
