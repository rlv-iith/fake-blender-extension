import typing
import collections.abc
import typing_extensions
import numpy.typing as npt
from . import submodule_1 as submodule_1


DATA_1: submodule_1.ClassA = None
""" DATA_1 description
"""
