import typing
import collections.abc
import typing_extensions
import numpy.typing as npt

DATA_1: int = None
""" DATA_1 description
"""
