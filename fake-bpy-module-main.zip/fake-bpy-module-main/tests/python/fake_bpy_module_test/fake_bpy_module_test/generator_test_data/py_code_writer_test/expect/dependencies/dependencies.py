import typing
import collections.abc
import typing_extensions
import numpy.typing as npt
import module_2


DATA_1: module_2.ClassA = None
""" DATA_1 description
"""
