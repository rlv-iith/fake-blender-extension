import typing
import collections.abc
import typing_extensions
import numpy.typing as npt
