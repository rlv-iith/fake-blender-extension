import module_1


i: int = 10
