import module_1


def add(x1, x2):
    pass


f: float = 0.5
