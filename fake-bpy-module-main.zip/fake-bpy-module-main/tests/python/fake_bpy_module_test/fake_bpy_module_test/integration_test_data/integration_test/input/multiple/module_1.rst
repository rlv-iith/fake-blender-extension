.. module:: module_1

base class --- module_1.submodule_1.BaseClass1

.. class:: ClassA

   ClassA description

   .. attribute:: attr_1

      attr_1 description

      :type: str

   .. method:: method_1(arg_1=5.4)

      method_1 description

      :arg arg_1: method_1 arg_1 description
      :type arg_1: float
      :return: method_1 return description
      :rtype: int
