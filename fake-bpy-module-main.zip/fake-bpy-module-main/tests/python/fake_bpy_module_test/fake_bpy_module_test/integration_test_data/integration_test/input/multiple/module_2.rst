.. module:: module_2


.. function:: function_1(arg_1, arg_2, arg_3, arg_4, arg_5)

   function_1 description

   :arg arg_1: function_1 arg_1 description
   :type arg_1: int
   :arg arg_2: function_1 arg_2 description
   :type arg_2: `module_1.ClassA`
   :arg arg_3: function_1 arg_3 description
   :type arg_3: enum in :ref:`rna_enum_enum1`, default 'ENUM_ITEM_1'
   :arg arg_4: Enumerator in :ref:`rna_enum_enum1`.
   :type arg_4: set
   :arg arg_5: job type in :ref:`rna_enum_enum1`.
   :type arg_5: function_1 arg_5 type
   :return: method_1 return description
   :rtype: `module_1.submodule_1.BaseClass1`
