.. module:: module_abc

.. class:: Class123

   Class123 description

   .. attribute:: attr_1

      attr_1 description

      :type: float

   .. method:: method_1()

      method_1 description

      :return: method_1 return description
      :rtype: int
