.. module:: module_1.submodule_1

.. class:: BaseClass1

   BaseClass1 description

   .. attribute:: attr_1

      attr_1 description

      :type: float

   .. method:: method_1()

      method_1 description

      :return: method_1 return description
      :rtype: int


.. function:: function_1(arg_1, arg_2)

   function_1 description

   :arg arg_1: function_1 arg_1 description
   :type arg_1: float
   :arg arg_2: function_1 arg_2 description
   :type arg_2: bool


.. data:: DATA_1

   DATA_1 description

   :type: str
