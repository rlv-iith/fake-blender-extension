.. module:: module_exceptional

.. class:: ClassExp

   ClassExp description

   .. attribute:: attr

      attr description

      :type: float

   .. method:: method_with_keyword_only_argument(arg_1, arg_2=5.0, arg_3)

      method_with_keyword_only_argument description

      :arg arg_1: method_with_keyword_only_argument arg_1 description
      :type arg_1: float
      :arg arg_2: method_with_keyword_only_argument arg_2 description
      :type arg_2: float
      :arg arg_3: method_with_keyword_only_argument arg_3 description
      :type arg_3: int

      :return: method_with_keyword_only_argument return description
      :rtype: int


.. function:: function_with_type_hint(arg_1: invalid_type, arg_2)

   function_with_type_hint description

   :arg arg_1: function_with_type_hint arg_1 description
   :type arg_1: float
   :arg arg_2: function_with_type_hint arg_2 description
   :type arg_2: bool

   :return: function_with_type_hint return description
   :rtype: int
