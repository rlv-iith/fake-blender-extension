.. module:: module_1.submodule_1

.. data:: data_2

   data_2 description

   :type: data_2 type
