.. mod-type:: append

.. module:: module_1

.. class:: ClassA

   .. base-class:: typing.Generic

      :mod-option base-class: skip-refine

   .. attribute:: attr_2

      attr_2 description

      :type: attr_2 type

   .. method:: method_2()

      :return: method_2 return description
      :rtype: method_2 return type

   .. method:: method_3(arg_1)

      method_3 description

      :arg arg_1: method_3 arg_1 description
      :type arg_1: method_3 arg_1 type
      :return: method_3 return description
      :rtype: method_3 return type
