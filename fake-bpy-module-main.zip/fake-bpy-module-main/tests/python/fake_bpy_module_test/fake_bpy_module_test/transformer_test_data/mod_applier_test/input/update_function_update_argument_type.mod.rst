.. mod-type:: update

.. module:: module_1

.. function:: function_2(*, arg_1=123)

   :mod-option arg arg_1: update-argument-type
