.. mod-type:: new

.. module:: module_1

.. function:: function_1()

   Duplication Skip

.. function:: function_3(arg_1, arg_2='TEST')

   function_3 description

   :arg arg_1: function_3 arg_1 description
   :type arg_1: function_3 arg_1 type
   :arg arg_2: function_3 arg_2 description
   :type arg_2: function_3 arg_2 type
   :return: function_3 return description
   :rtype: function_3 return type
   :generic-types: _GenericType1
