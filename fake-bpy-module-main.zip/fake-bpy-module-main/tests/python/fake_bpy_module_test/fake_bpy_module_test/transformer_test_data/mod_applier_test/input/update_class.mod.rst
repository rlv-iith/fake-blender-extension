.. mod-type:: update

.. module:: module_1

.. class:: ClassA

   :generic-types: _GenericType1

   .. base-class:: BaseClass

   .. attribute:: attr_1

      updated attr_1 description

      :type: updated attr_1 type

   .. method:: method_1()

      updated method_1 description

      :return: updated method_1 return description
      :rtype: updated method_1 return type

   .. method:: method_2(arg_1)

      :arg arg_1: updated method_2 arg_1 description
      :type arg_1: updated method_2 arg_1 type
      :generic-types: _GenericType2
