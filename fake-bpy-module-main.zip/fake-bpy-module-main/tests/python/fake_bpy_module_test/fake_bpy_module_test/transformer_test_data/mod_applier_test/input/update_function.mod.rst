.. mod-type:: update

.. module:: module_1

.. function:: function_1()

   updated function_1 description

   :return: updated function_1 return description
   :rtype: updated function_1 return type

.. function:: function_2(arg_1)

   :arg arg_1: updated function_2 arg_1 description
   :type arg_1: updated function_2 arg_1 type
   :generic-types: _GenericType1
