.. mod-type:: new

.. module:: module_1

.. data:: DATA_1

   Duplication Skip

.. data:: DATA_2

   DATA_2 description

   :type: DATA_2 type
