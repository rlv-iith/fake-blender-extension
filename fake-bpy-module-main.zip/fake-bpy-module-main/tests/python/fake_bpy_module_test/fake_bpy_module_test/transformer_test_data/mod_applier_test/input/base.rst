.. module:: module_1


.. data:: DATA_1

   DATA_1 description

   :type: DATA_1 type


.. function:: function_1(arg_1)

   function_1 description

   :arg arg_1: function_1 arg_1 description
   :type arg_1: function_1 arg_1 type
   :return: function_1 return description
   :rtype: function_1 return type


.. function:: function_2(arg_1)

   function_2 description

   :arg arg_1: function_2 arg_1 description
   :type arg_1: function_2 arg_1 type


.. class:: ClassA

   ClassA description

   .. attribute:: attr_1

      attr_1 description

      :type: attr_1 type

   .. method:: method_1(arg_1)

      method_1 description

      :arg arg_1: method_1 arg_1 description
      :type arg_1: method_1 arg_1 type
      :return: method_1 return description
      :rtype: method_1 return type

   .. method:: method_2(arg_1)

      :arg arg_1: method_2 arg_1 description
      :type arg_1: method_2 arg_1 type
