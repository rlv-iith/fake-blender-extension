.. mod-type:: append

.. module:: module_1

.. function:: function_1(arg_2=10)

   :arg arg_2: function_1 arg_2 description
   :type arg_2: function_1 arg_2 type


.. function:: function_2()

   :rtype: function_2 return type
   :return: function_2 return description
