.. mod-type:: update

.. module:: module_1

.. data:: DATA_1

   :type: DATA_1 type updated
