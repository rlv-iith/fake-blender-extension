.. mod-type:: new

.. module:: module_1

.. data:: DATA_1

   :type: DATA_1 type
   :mod-option: skip-refine

.. function:: function_1(arg_1)

   :type arg_1: function_1 arg_1 type
   :mod-option arg arg_1: skip-refine
   :rtype: function_1 return type
   :mod-option rtype: skip-refine
