.. module:: module_1


.. class:: ClassA

   ClassA description

   .. base-class:: `refined_module_d.RefinedClassG`

   .. attribute:: attr_1

      attr_1 description

      :type: :class:`RefinedClassA`

   .. method:: method_1(arg_1)

      method_1 description

      :arg arg_1: method_1 arg_1 description
      :type arg_1: :class:`RefinedClassB`
      :return: method_1 return description
      :rtype: :class:`refined_module_a.RefinedClassA`


.. function:: function_1(arg_1, arg_2)

   function_1 description

   :arg arg_1: function_1 arg_1 description
   :type arg_1: :class:`refined_module_b.RefinedClassC`
   :arg arg_2: function_1 arg_2 description
   :type arg_2: :class:`RefinedClassD`
   :return: function_1 return description
   :rtype: :class:`refined_module_a.RefinedClassE`


.. data:: data_1

   data_1 description

   :type: :class:`refined_module_c.RefinedClassF`
