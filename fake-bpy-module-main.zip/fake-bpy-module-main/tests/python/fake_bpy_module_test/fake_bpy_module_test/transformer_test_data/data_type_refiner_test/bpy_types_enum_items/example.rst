.. _rna_enum_example:

Example
####################################

:ONE: One.

   Item one
:TWO: Two.

   Item two