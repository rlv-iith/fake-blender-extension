.. module:: module_1

.. class:: ClassA

   .. method:: method_1()

      :return: An instance of this object.

   .. method:: method_2(arg_1, arg_2, arg_3)

      :arg arg_1: Enumerator in :ref:`rna_enum_example`.
      :type arg_1: set
      :arg arg_2: job type in :ref:`rna_enum_example`.
      :type arg_2: method_2 arg_2 type
      :arg arg_3: Enumerator in :ref:`rna_enum_example`.
      :type arg_3: set[str]
