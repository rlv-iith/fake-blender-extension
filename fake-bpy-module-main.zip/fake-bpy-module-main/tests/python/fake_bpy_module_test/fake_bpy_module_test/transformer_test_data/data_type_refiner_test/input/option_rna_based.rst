.. module:: bpy.types

.. function:: function_1(arg_optional, arg_readonly, arg_never_none)

   :arg arg_optional: function_1 arg_optional description
   :type arg_optional: int (optional)
   :arg arg_readonly: function_1 arg_readonly description
   :type arg_readonly: int (readonly)
   :arg arg_never_none: function_1 arg_never_none description
   :type arg_never_none: int (never none)

.. function:: function_2(arg_1)

   :arg arg_1: function_2 arg_1 description
   :type arg_1: int (optional, readonly, never none)

.. class:: ClassA

   .. attribute:: active_attr

      :type: int

.. class:: ID

   .. attribute:: library

      :type: int

.. data:: active_data

   :type: int
