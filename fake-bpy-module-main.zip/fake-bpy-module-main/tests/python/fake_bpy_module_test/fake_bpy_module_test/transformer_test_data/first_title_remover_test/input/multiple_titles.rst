First Title
===================

.. module:: module_1

.. data:: DATA_1

   DATA_1 description

   :type: DATA_1 type

Second Title
===================
