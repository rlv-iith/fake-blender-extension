.. module:: module_1

base class --- BaseClass1

.. class:: ClassA

   ClassA description

.. class:: BaseClass1

   BaseClass1 description
