.. module:: bpy.props

.. function:: function_1(arg_1, arg_2=5.0)

   function_1 description

   :arg arg_1: function_1 arg_1 description
   :type arg_1: function_1 arg_1 type
   :arg arg_2: function_1 arg_2 description
   :type arg_2: function_1 arg_2 type
