.. module:: bpy.types

.. class:: Attribute1

.. class:: Attribute2

.. class:: Attributes1

.. class:: Attributes2

.. class:: ClassA

   ClassA description

   .. attribute:: attr_1

      attr_1 description

      :type: :class:`Attributes1` :class:`bpy_prop_collection` of :class:`Attribute1`, (readonly)

   .. attribute:: attr_2

      attr_2 description

      :type: :class:`Attributes2` :class:`bpy_prop_collection` of :class:`Attribute2`

