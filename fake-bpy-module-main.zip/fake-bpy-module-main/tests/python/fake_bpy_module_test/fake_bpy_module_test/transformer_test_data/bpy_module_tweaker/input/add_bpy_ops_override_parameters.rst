.. module:: bpy.ops.pose


.. function:: function_1(arg_1)

   function_1 description

   :arg arg_1: function_1 arg_1 description
   :type arg_1: function_1 arg_1 type

.. function:: function_2()

   function_2 description
