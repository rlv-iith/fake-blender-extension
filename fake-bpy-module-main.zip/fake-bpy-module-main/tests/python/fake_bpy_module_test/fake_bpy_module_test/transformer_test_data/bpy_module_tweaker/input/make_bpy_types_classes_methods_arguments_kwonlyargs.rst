.. module:: bpy.types

.. class:: UILayout

   .. method:: method_1(arg_1, arg_2, arg_3="test", arg_4=123)

      :arg arg_1: method_1 arg_1 description
      :type arg_1: int
      :arg arg_2: method_1 arg_2 description
      :type arg_2: bool
      :arg arg_3: method_1 arg_3 description
      :type arg_3: str
      :arg arg_4: method_1 arg_4 description
      :type arg_4: int
