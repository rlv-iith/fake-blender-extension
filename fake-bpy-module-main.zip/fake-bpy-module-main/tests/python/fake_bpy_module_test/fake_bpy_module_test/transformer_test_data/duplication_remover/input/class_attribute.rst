.. module:: module_1

.. class:: ClassA

   .. attribute:: attr_1

      :type: int

   .. attribute:: attr_1

      :type: int
