.. module:: module_1

.. function:: function_1(arg_1)

   :arg arg_1: function_1 arg_1 description
   :type arg_1: function_1 arg_1 type

.. function:: function_1(arg_1)

   :arg arg_1: function_1 arg_1 description
   :type arg_1: function_1 arg_1 type
