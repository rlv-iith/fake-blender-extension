.. module:: module_1

.. class:: ClassA

   .. attribute:: attr_1

      :type: int

   .. method:: method_1(arg_1)

      :type arg_1: int
      :rtype: bool


.. class:: ClassA

   .. attribute:: attr_1

      :type: int

   .. method:: method_1(arg_1)

      :type arg_1: int
      :rtype: bool
