.. module:: module_1

.. function:: function_1(arg_1, arg_2, arg_3, arg_1)

   :arg arg_1: function_1 arg_1 description
   :type arg_1: function_1 arg_1 type
   :arg arg_2: function_1 arg_2 description
   :type arg_2: function_1 arg_2 type
   :arg arg_3: function_1 arg_3 description
   :type arg_3: function_1 arg_3 type

.. class:: ClassA

   .. method:: method_1(arg_1, arg_1)

      :arg arg_1: method_1 arg_1 description
      :type arg_1: method_1 arg_1 type
