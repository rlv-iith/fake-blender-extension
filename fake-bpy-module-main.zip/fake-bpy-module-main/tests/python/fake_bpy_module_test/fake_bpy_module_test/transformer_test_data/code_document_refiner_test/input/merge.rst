.. module:: module_1

.. warning::

   Warning Contents

.. data:: DATA_1

   DATA_1 description

   :type: DATA_1 type

.. note::

   Note Contents
