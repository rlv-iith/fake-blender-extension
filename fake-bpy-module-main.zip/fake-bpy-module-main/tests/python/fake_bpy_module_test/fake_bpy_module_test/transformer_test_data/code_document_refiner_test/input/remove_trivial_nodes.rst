.. module:: module_1

.. data:: DATA_1

   DATA_1 description

   :type: DATA_1 type

Some descriptions 1

.. rubric:: Inherited Functions

.. hlist::

   * To be removed

Some descriptions 2

.. rubric:: Inherited Properties

.. hlist::

   * To be removed

Some descriptions 3

.. rubric:: References

.. hlist::

   * To be removed

Some descriptions 4
