.. _rna_enum_basic:

Basic
#####

:BASIC_ONE: One.

   Description.
:BASIC_TWO: Two.

   Description.
