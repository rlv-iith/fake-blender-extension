.. module:: module_1

.. class:: ClassA

   .. attribute:: attr_1

      :type: :class:`ClassA`

   .. attribute:: attr_2

      :type: :class:`ClassB`

   .. method:: method_1(arg_1, arg_2)

      :type arg_1: :class:`ClassA`
      :type arg_2: :class:`ClassB`
      :rtype: :class:`ClassA`

.. class:: ClassB
