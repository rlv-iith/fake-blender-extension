.. module:: module_2

.. data:: data_3

   data_3 description

   :type: data_3 type
