.. module:: bpy.types

.. class:: Context

   context

   .. attribute:: attr_1

      attr_1 description

      :type: attr_1 type