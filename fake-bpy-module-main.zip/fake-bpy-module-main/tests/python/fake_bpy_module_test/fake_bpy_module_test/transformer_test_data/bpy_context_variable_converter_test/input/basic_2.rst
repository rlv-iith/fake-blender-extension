.. module:: bpy.context

.. data:: attr_2

    attr_2 description

    :type: attr_2 type