# Setup IDE: All Text Editor (Install as Python module)

Tutorial Video is available on YouTube.  
Thanks **@GDquest** for creating a great tutorial video!

[![Tutorial (Video)](https://img.youtube.com/vi/IQgLBnPO2uo/0.jpg)](https://www.youtube.com/watch?v=IQgLBnPO2uo)

## 1. Check the generated modules location

Check the location of the generated modules.  

## 2. Install the modules as the Python module

1. Search and go to the directory `Python.exe` binary is installed.
2. Place the generated modules to the `Lib` directory.

Note: Be sure the Python version that you are using
