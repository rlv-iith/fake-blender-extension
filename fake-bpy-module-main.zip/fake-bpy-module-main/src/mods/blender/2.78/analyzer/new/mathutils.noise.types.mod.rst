.. mod-type:: new

.. module:: mathutils.noise.types

.. data:: STDPERLIN

   :type: int
