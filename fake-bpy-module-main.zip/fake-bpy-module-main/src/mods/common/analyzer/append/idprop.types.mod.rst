.. mod-type:: append

.. module:: idprop.types


.. class:: idprop.types.IDPropertyGroupViewItems

   .. base-class:: collections.abc.Iterable[tuple[str, typing.Any]]

      :mod-option base-class: skip-refine

.. class:: idprop.types.IDPropertyGroupViewKeys

   .. base-class:: collections.abc.Iterable[str]

      :mod-option base-class: skip-refine

.. class:: idprop.types.IDPropertyGroupViewValues

   .. base-class:: collections.abc.Iterable[typing.Any]

      :mod-option base-class: skip-refine
