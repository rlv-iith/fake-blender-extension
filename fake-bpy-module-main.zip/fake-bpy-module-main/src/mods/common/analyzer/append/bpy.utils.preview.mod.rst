.. mod-type:: append

.. module:: bpy.utils.previews

.. class:: ImagePreviewCollection

   .. base-class:: dict[str, bpy.types.ImagePreview]

      :mod-option base-class: skip-refine
