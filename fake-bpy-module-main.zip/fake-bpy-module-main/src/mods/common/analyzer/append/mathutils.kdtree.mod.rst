.. mod-type:: append

.. module:: mathutils.kdtree

.. class:: KDTree

   .. method:: __init__(size)
