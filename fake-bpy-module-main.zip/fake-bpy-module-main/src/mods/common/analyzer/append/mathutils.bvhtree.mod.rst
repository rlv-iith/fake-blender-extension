.. mod-type:: append

.. module:: mathutils.bvhtree

.. class:: BVHTree

   .. method:: __init__(size)
