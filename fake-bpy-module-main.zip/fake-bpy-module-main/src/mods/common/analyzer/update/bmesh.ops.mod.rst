.. mod-type:: update

.. module:: bmesh.ops

.. function:: split_edges(bm, edges=[], verts=[], use_verts=False)
