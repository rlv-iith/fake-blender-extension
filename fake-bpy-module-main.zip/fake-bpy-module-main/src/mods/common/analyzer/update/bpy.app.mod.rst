.. mod-type:: update

.. module:: bpy.app

.. data:: version

   :type: tuple[int, int, int]
   :mod-option: skip-refine

.. data:: binary_path

   :type: str
   :mod-option: skip-refine
